package com.example.e_farming;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Farm extends AppCompatActivity {
    Button b1,b2,b3,b4;
    TextView t1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farm);
        t1 = findViewById(R.id.msg);
        b1 = findViewById(R.id.Sales);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1,create an instance for intent
                Intent myIntent = new Intent(Farm.this, sales.class);

                //2.startActivity(object)
                startActivity(myIntent);
            }
        });
        b2 = findViewById(R.id.delivery);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override

        public void onClick (View view){
            //1,create an instance for intent
            Intent myInt = new Intent(Farm.this,delivery.class);

            //2.startActivity(object)
            startActivity(myInt);
        }
    });
        b3=findViewById(R.id.logout);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1,create an instance for intent
                Intent myInt = new Intent(Farm.this, MainActivity.class);

                //2.startActivity(object)
                startActivity(myInt);
            }
        });
        b4=findViewById(R.id.buy);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1,create an instance for intent
                Intent myInt = new Intent(Farm.this, Buyer.class);

                //2.startActivity(object)
                startActivity(myInt);
            }
        });

    }
}