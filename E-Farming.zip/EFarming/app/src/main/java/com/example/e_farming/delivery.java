package com.example.e_farming;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class delivery extends AppCompatActivity {
    TextView t1,t2,t3,t4,t5,t6,t7;
    Button b1;
    @SuppressLint("MissingInflatedId")
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery);
        t1=findViewById(R.id.view1);
        t2=findViewById(R.id.view2);
        t3=findViewById(R.id.view3);
        t4=findViewById(R.id.view4);
        t5=findViewById(R.id.view5);
        t6=findViewById(R.id.view6);
        t7=findViewById(R.id.view7);
        b1=findViewById(R.id.go_back);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1,create an instance for intent
                Intent myIntent = new Intent(delivery.this, Farm.class);

                //2.startActivity(object)
                startActivity(myIntent);
            }
        });


    }
}