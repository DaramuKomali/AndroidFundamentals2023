package com.example.e_farming;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Signfarm extends AppCompatActivity {
    RadioGroup r;
    RadioButton c;
    TextView t1;
    EditText e1, e2, e3, e4, e5, e6;
    DataHelper db;
    Datahelperforcon db1;
    Button submit;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signfarm);
        t1 = findViewById(R.id.join);
        e1 = findViewById(R.id.name);
        e2 = findViewById(R.id.num);
        e3 = findViewById(R.id.mail);
        e4 = findViewById(R.id.pass);
        e5 = findViewById(R.id.repass);
        e6 = findViewById(R.id.place);

        r = findViewById(R.id.radioGroup);
        submit = findViewById(R.id._submit);
        db = new DataHelper(this);
        db1 = new Datahelperforcon(this);
        RadioGroup r = findViewById(R.id.radioGroup);

        submit.setOnClickListener(view -> {
            String s = e1.getText().toString();
            String s1 = e2.getText().toString();
            String s2 = e3.getText().toString();
            String s3 = e4.getText().toString();
            String s4 = e6.getText().toString();
            String s5 = e5.getText().toString();
            if (s3.equals(s5)) {
                int selectedId = r.getCheckedRadioButtonId();
                c = findViewById(selectedId);
                if ((c.getText().toString()).equals("producer")) {
                    boolean result = db.setdata(s, s1, s2, s3, s4);
                    if (result) {
                        Toast.makeText(Signfarm.this, "producer you successfully sign in", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Signfarm.this, producer.class));
                    } else
                        Toast.makeText(Signfarm.this, "producer data not inserted", Toast.LENGTH_SHORT).show();

                } else {
                    boolean result = db1.setdata1(s, s1, s2, s3, s4);
                    if (result) {
                        Toast.makeText(Signfarm.this, "consumer you successfully sign in", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Signfarm.this, Consumer.class));
                    } else
                        Toast.makeText(Signfarm.this, " consumer data not inserted", Toast.LENGTH_SHORT).show();

                }
            } else {
                Toast.makeText(Signfarm.this, "password and repassword are not same", Toast.LENGTH_SHORT).show();
            }
        });
    }
    
}