package com.example.e_farming;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;


@SuppressLint("CustomSplashScreen")
public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
//to show the splash screen fo 3 sec next moves to main activity
        Handler handler = new Handler();
        handler.postDelayed(() -> startActivity(new Intent(SplashScreen.this, MainActivity.class)), 3000);
    }
}
