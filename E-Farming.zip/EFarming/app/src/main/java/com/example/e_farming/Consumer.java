package com.example.e_farming;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Consumer extends AppCompatActivity {
    EditText e1,e2,e3,e4;
    Button login;
    Datahelperforcon db1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consumer);
        e1=findViewById(R.id.name);
        e3=findViewById(R.id.mail);
        e4=findViewById(R.id.location);
        login=findViewById(R.id.log_in);
        db1=new Datahelperforcon(this);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=e1.getText().toString();
                String s1=e3.getText().toString();
                String s2=e4.getText().toString();
                boolean result=db1.getdata1(s,s1,s2);
                if(result) {
                    Toast.makeText(Consumer.this, "consumer successfully login", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Consumer.this,Farm.class));
                }
                else{
                    Toast.makeText(Consumer.this, "please signin", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}