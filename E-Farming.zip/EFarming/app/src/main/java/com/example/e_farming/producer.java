package com.example.e_farming;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class producer extends AppCompatActivity {
    EditText e1,e2,e3,e4;
    Button login;
    DataHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_producer);
        e1=findViewById(R.id.name);
        e3=findViewById(R.id.mail);
        e4=findViewById(R.id.pass);
        login=findViewById(R.id._login);
        db=new DataHelper(this);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               String s=e1.getText().toString();
               String s1=e3.getText().toString();
               String s2=e4.getText().toString();
               boolean result=db.getdata(s,s1,s2);
               if(result) {
                   Toast.makeText(producer.this, "producer successfully login", Toast.LENGTH_SHORT).show();
                   Intent intent= new Intent(producer.this,Crops.class);
                   startActivity(intent);
               }
               else {
                   Toast.makeText(producer.this, "please signin", Toast.LENGTH_SHORT).show();
               }

            }
        });


    }
}