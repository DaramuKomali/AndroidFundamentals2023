package com.example.e_farming;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Add extends AppCompatActivity {
    Button next;
    TextView t1,t2,t3,t4;
    EditText e1,e2,e3,e4;
    ArrayList<String> a1;
    ArrayList<String> a2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        next=findViewById(R.id._next);
        t1=findViewById(R.id._text1);
        t2=findViewById(R.id._text2);
        t3=findViewById(R.id._text3);
        t4=findViewById(R.id._text4);
        e1=findViewById(R.id._edit1);
        e2=findViewById(R.id._edit2);
        e3=findViewById(R.id._edit3);
        e4=findViewById(R.id._edit4);
        a1=new ArrayList<>();
        a2=new ArrayList<>();
        a1=getIntent().getExtras().getStringArrayList("foodnames");
        for(int i=0;i<a1.size();i++) {
            if (i == 0)
                t1.setText(a1.get(0));
            else if (i == 1)
                t2.setText(a1.get(1));
            else if (i == 2)
                t3.setText(a1.get(2));
            else if (i == 4)
                t4.setText(a1.get(3));
        }
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for(int i=0;i<a1.size();i++) {
                    if (i == 0)
                        a2.add(e1.getText().toString());
                    else if (i == 1)
                        a2.add(e2.getText().toString());
                    else if (i == 2)
                        a2.add(e3.getText().toString());
                    else if (i == 4)
                        a2.add(e4.getText().toString());
                }
                Intent intent=new Intent(Add.this,Product.class);
                intent.putExtra("quantity",a2);
                intent.putExtra("names",a1);
                startActivity(intent);

            }
        });
    }
}