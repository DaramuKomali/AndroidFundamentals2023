package com.example.e_farming;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Crops extends AppCompatActivity {

    TextView t1;
    CheckBox c1,c2,c3,c4,c5,c6;
    Button b1;
    ArrayList<String> a;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crops);
        t1 = findViewById(R.id.crops);
        c1 = findViewById(R.id.check1);
        c2 = findViewById(R.id.check2);
        c3 = findViewById(R.id.check3);
        c4 = findViewById(R.id.check4);
        c5 = findViewById(R.id.check5);
        c6 = findViewById(R.id.check6);
        b1 = findViewById(R.id.btn);
        a = new ArrayList<>();
        b1.setOnClickListener(this::onClick);
    }
    private void onClick(View view){
            if (c1.isChecked()) {
                a.add(c1.getText().toString());
            }
            if (c2.isChecked()) {
                a.add(c2.getText().toString());
            }
            if (c3.isChecked()) {
                a.add(c3.getText().toString());
            }
            if (c4.isChecked()) {
                a.add(c4.getText().toString());
            }
            if (c5.isChecked()) {
                a.add(c5.getText().toString());
            }
            if (c6.isChecked()) {
                a.add(c6.getText().toString());
            }
            Intent intent = new Intent(Crops.this, Add.class);
            intent.putExtra("foodnames", a);
            startActivity(intent);
    }
}
