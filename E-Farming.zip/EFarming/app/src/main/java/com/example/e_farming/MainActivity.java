package com.example.e_farming;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3;
    TextView v1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        v1=findViewById(R.id.account);
        b1=findViewById(R.id.producer);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1,create an instance for intent
                Intent myIntent = new Intent(MainActivity.this, producer.class);

                //2.startActivity(object)
                startActivity(myIntent);
            }
        });
        b2=findViewById(R.id.consumer);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1,create an instance for intent
                Intent myInten = new Intent(MainActivity.this, Consumer.class);

                //2.startActivity(object)
                startActivity(myInten);
            }
        });
        b3=findViewById(R.id.sign);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1,create an instance for intent
                Intent myInt = new Intent(MainActivity.this, Signfarm.class);

                //2.startActivity(object)
                startActivity(myInt);
            }
        });

    }
}