package com.example.e_farming;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class Prices extends AppCompatActivity {
    Button conform;
    TextView text;
    ArrayList<String> a,a1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prices);
        text=findViewById(R.id._textView);
        conform=findViewById(R.id._conform);
        a=new ArrayList<>();
        a1=new ArrayList<>();
        String s="";
        a=getIntent().getExtras().getStringArrayList("quantity");
        a1=getIntent().getExtras().getStringArrayList("names");
        for(int i=0;i<a.size();i++){
            int j=Integer.parseInt(a.get(i));
            if(i==0){
               s=s+a1.get(i)+"\t\t\t"+String.valueOf(j*40)+"\n";

            }
           else  if(i==1){
                s=s+a1.get(i)+"\t\t\t"+String.valueOf(j*80)+"\n";

            }
            else if(i==2){
                s=s+a1.get(i)+"\t\t\t"+String.valueOf(j*90)+"\n";

            }
            else if(i==3){
                s=s+a1.get(i)+"\t\t\t"+String.valueOf(j*25)+"\n";

            }

        }
        text.setText(s);
        conform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Prices.this,Conformation.class);
                startActivity(intent);
            }
        });
    }
}