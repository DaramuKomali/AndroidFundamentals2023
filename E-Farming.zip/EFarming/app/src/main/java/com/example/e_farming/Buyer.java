package com.example.e_farming;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class Buyer extends AppCompatActivity {
    TextView t1;
    CheckBox c1,c2,c3,c4,c5,c6;
    Button b1;
   ArrayList<String> a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buyer);
        t1=findViewById(R.id.choose);
        c1=findViewById(R.id.paddy);
        c2=findViewById(R.id._wheat);
        c3=findViewById(R.id.jower);
        c4=findViewById(R.id.mirchi);
        c5=findViewById(R.id.cotton);
        c6=findViewById(R.id.redgram);
        b1=findViewById(R.id.back);
        a=new ArrayList<>();
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(c1.isChecked()){
                    a.add(c1.getText().toString());
                }
                if(c2.isChecked()) {
                    a.add(c2.getText().toString());
                }
                if(c3.isChecked()) {
                    a.add(c3.getText().toString());
                }
                if(c4.isChecked()){
                    a.add(c4.getText().toString());
                }
                if(c5.isChecked()){
                    a.add(c5.getText().toString());
                }
                if(c6.isChecked()){
                    a.add(c6.getText().toString());
                }
                    Intent intent=new Intent(Buyer.this,Quantity.class);
                intent.putExtra("foodnames",a);
                startActivity(intent);

            }
        });

    }
}