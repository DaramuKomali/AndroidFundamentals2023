
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataHelper extends SQLiteOpenHelper {

    private Object String;

    public DataHelper(@Nullable Context context) {
        super(context, "logindetails.db", 1, null);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table login(name text primary key,phonenumber text,email text,password text,place text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public boolean setdata(String name, String phonenumber, String email, String password, String place) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("phonenumber", phonenumber);
        {
            contentValues.put("email", email);
            contentValues.put("password", password);
            contentValues.put("place", place);
            long result = db.insert("login", null, contentValues);
            if (result == -1) return false;
            else return true;


        }

    }


}
